// Inferring schema using reflection

import spark.implicits._

// Create the RDD clines using textFile. Elements in the RDD are of type string
val clines = sc.textFile("sparkinput/customers.tsv")
clines.take(5).foreach(println)

clines.first() // Check the data type of the RDD element
clines.take(5) // Check the data type of the Array of the RDD elements

case class c_schema(cid: Integer, cname: String, ccity: String, cstate: String, czip: Integer)

// Create the RDD customerRDD mapping the sub-strings to each field in the case class c_schema. Elements in the RDD are of type c_schema
val customersRDD = clines.map(_.split("\t")).map(f => c_schema(f(0).toInt,f(1),f(2),f(3),f(4).toInt))
customersRDD.take(5).foreach(println)

customersRDD.first() // Check the data type of the RDD element
customersRDD.take(5) // Check the data type of the Array of the RDD elements

// Create DataFrame customerDF from the RDD customersRDD
val customerDF = customersRDD.toDF()
customerDF.printSchema()
customerDF.show()

// DataFrame operations on customerDF
customerDF.select("cname").show(false)

// Selecting multiple columns
customerDF.select("cname", "ccity").show()

// Variation in syntax in referring to fields/columns
customerDF.select(customerDF("cname")).show()
customerDF.select($"ccity").show()

// Filter
customerDF.filter($"cstate" === "CA").show()
customerDF.filter(col("cstate") === "CA").show()
customerDF.filter(customerDF("cstate") === "CA").show()

customerDF.where($"cstate" === "CA").show()
customerDF.where(col("cstate") === "CA").show()
customerDF.where(customerDF("cstate") === "CA").show()

// Group By
customerDF.groupBy("cstate").count().show()
