/*
==============================
spark2-shell --master local[*]
==============================
df_from_datasources
====================
*/

import org.apache.spark.sql.SparkSession

val customerDF = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").option("header","true").load("sparkdata/customers.txt")

customerDF.printSchema()
customerDF.select("customer_name").show()
customerDF.select($"customer_id", $"customer_name").show()

customerDF.filter($"customer_state" === "CA").show()
// customerDF.filter("customer_state" === "CA").show() // Gives an error as filter considers "customer_State" as a string
customerDF.filter(col("customer_state") === "CA").show()
customerDF.filter(customerDF("customer_state") === "CA").show()
customerDF.where($"customer_state" === "CA").show()

customerDF.groupBy("customer_state").count().show()
customerDF.groupBy("customer_state").agg(count("customer_state")).show()
customerDF.groupBy("customer_state").agg(count("customer_state").as("customer_number")).show()
// Aggregatons like sum, mon, max, avg can be done

customerDF.createOrReplaceTempView("customers")
val cStateCount50 = spark.sql("SELECT customer_state, count(*) as state_count FROM customers GROUP BY customer_state HAVING state_count>=50")

cStateCount50
cStateCount50.show()
cStateCount50.printSchema()

cStateCount50.coalesce(1).write.save("cStateOutput1")
// cStateCount50.coalesce(1).write.parquet("cStateOutput2")
// cStateCount50.coalesce(1).write.format("parquet").save("cStateOutput3")

cStateCount50.coalesce(1).write.format("json").save("cStateOutputJSON1")
// cStateCount50.coalesce(1).write.json("cStateOutputJSON2")

// JSON read to be To be added

val productDF = spark.read.format("json").load("sparkdata/products.json")
// val productDF2 = spark.read.json("sparkinput/products.json")
productDF.select("product_name").show()
productDF.select($"product_name",$"product_category",$"product_price").show()
productDF.select($"product_name",$"product_category",$"product_price").show(5,false) // To show 5 records without truncation
productDF.filter($"product_price">200.00).show()
productDF.groupBy("product_category").count().show()

productDF.groupBy("product_category").agg(sum("product_price").as("sum_price")).show(false)

productDF.groupBy("product_category").agg(sum("product_price").as("sum_price"), avg("product_price").as("avg_price")).show(false)

productDF.groupBy("product_category").agg(sum("product_price").as("sum_price"), avg("product_price").as("avg_price"), max("product_price").as("max_price")).show(false)

productDF.groupBy("product_category").agg(sum("product_price").as("sum_price"), avg("product_price").as("avg_price"), max("product_price").as("max_price"), min("product_price").as("min_price")).show(false)

productDF.groupBy("product_category").
    agg(
        sum("product_price").as("sum_price"),
        avg("product_price").as("avg_price"),
        max("product_price").as("max_price"),
        min("product_price").as("min_price")
    ).
    show(false)

productDF.createOrReplaceTempView("products")
val prd200 = spark.sql("SELECT category_id, product_category, count(*) as prdcount FROM products WHERE product_price>200 GROUP BY category_id, product_category ORDER BY product_category")
prd200
prd200.show()
prd200.printSchema()

prd200.coalesce(1).write.save("prdOutput1")
// prd200.coalesce(1).write.parquet("prdOutput2")
// prd200.coalesce(1).write.format("parquet").save("prdOutput3")

prd200.coalesce(1).write.format("json").save("prdOutputj1")
// prd200.coalesce(1).write.json("prdOutputj2")

prd200.coalesce(1).write.format("csv").option("sep", "\t").option("header","true").save("prdOutputc1")
// prd200.coalesce(1).write.option("sep", "\t").option("header","true").csv("prdOutputc2")

/*
Now that we have two datasets in two views we can join them on the common column for queries. For example:
Get the list of customers and product categories in which they bought multiple items (quantity) that are more expensive than 200.00
*/
val custlist200 = spark.sql("SELECT a.customer_name, b.product_category, count(*) as prdcount FROM customers a INNER JOIN products b ON a.customer_id=b.customer_id WHERE b.product_price>200.00 GROUP BY a.customer_name, b.product_category HAVING prdcount>1")

val newfmt = spark.sql("SELECT salestxn_id, product_name, (category_id, product_category) as category_details, product_price, product_quantity, customer_id from products")
newfmt.coalesce(1).write.json("newfmtJSON")


import org.apache.spark.sql.functions._

// Using withColumn Change Column Data Type
val prodDF2=productDF.withColumn("customer_id",col("customer_id").cast("Integer"))
prodDF2.printSchema()
prodDF2.show(5)

// Using withColumn add a new column with constant
val prodDF3=prodDF2.withColumn("discount",lit(10.0))
prodDF3.printSchema()
prodDF3.show(5)

// Using withColumn add a new column calculated with existing columns
val prodDF4=prodDF3.withColumn("discounted_price",$"product_price"*0.9)
prodDF4.printSchema()
prodDF4.show(5)

// withColumnRenamed
val prodDF5=prodDF4.withColumnRenamed("customer_id","customer_number")
prodDF5.printSchema()
prodDF5.show(5)

// join
val newDF=customerDF.join(prodDF5,customerDF("customer_id") === prodDF5("customer_number"),"outer")
newDF.printSchema()
newDF.show(5)

newDF.where($"customer_state" === "IL").show(25)

newDF.select("customer_id","customer_name","customer_city","customer_state","customer_number","product_name","product_price","product_quantity").where(col("customer_state")==="IL").show()

// df.na.fill on columns with a string type data
val newDF2=newDF.na.fill("NA",Array("product_name","product_category"))
newDF2.printSchema()
newDF2.select("customer_id","customer_name","customer_city","customer_state","customer_number","product_name","product_price","product_quantity").where(col("customer_state")==="IL").show()

# df.na.fill on columns with an integer type data
val newDF3=newDF2.na.fill(0,Array("salestxn_id","category_id"))
newDF3.printSchema()
newDF3.select("customer_id","customer_name","customer_city","customer_state","customer_number","product_name","product_price","product_quantity","category_id","salestxn_id").where($"customer_state"==="IL").show()

val collist=newDF.columns
collist
collist.foreach(println)
