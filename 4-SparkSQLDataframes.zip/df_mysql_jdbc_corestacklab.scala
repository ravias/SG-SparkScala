$ mysql -hdatabase.claas.cloudlab.com -uclaasuser_read -p"2KD4nPDnyrZ@5jUKH"

$ spark2-shell --master local[*] --driver-class-path /usr/share/java/mysql-connector-java.jar --jars /usr/share/java/mysql-connector-java.jar

scala>
scala>
val jdbcDF = spark.read.format("jdbc").option("url", "jdbc:mysql://database.claas.cloudlab.com").option("dbtable", "lab_exercise.cctab").option("user", "claasuser_read").option("password", "2KD4nPDnyrZ@5jUKH").load()

jdbcDF.printSchema()
jdbcDF.show()
jdbcDF.count()

// Using Properties
import java.util.Properties

val connectionProperties = new Properties()
connectionProperties.put("user", "claasuser_read")
connectionProperties.put("password", "2KD4nPDnyrZ@5jUKH")

val jdbcDF2 = spark.read.jdbc("jdbc:mysql://database.claas.cloudlab.com", "lab_exercise.cctab", connectionProperties)

jdbcDF2.printSchema()
jdbcDF2.show()
jdbcDF2.count()

// Saving data to a JDBC source
// The user needs to have write i.e. create table permissions to the database
jdbcDF.write.format("jdbc").option("url", "jdbc:mysql://database.claas.cloudlab.com").option("dbtable", "lab_exercise.cctab").option("user", "userid").option("password", "passwordstring").save()

jdbcDF2.write.jdbc("jdbc:mysql://database.claas.cloudlab.com", "lab_exercise.cctab", connectionProperties)
